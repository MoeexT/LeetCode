#! py -3

import csv
import sys
import random
import networkx as nx
from matplotlib import pyplot as plt


# 图的顶点
class Node():
    def __init__(self, type, name, x, y):
        # 节点信息
        self.type = type  # 类型
        self.name = name  # 名称
        self.x = int(x)  # 坐标
        self.y = int(y)
        # 生成树相关信息
        self.next = []  # 相连的节点
        self.next_d = sys.maxsize  # 与相邻节点的距离

    def __str__(self):
        # "{type}:{x},{y} -{:.2f}-> {type}{x1}{y1}"
        if self.next != None:
            """ return "{}:{},{} -[{:.2f}]-> {}:{},{}".format(
                self.name, self.x, self.y, self.next_d,
                self.next.name, self.next.x, self.next.y
            ) """
            return "{} -> {}".format(self.name, self.next)
        else:
            return "{}:{},{}".format(self.name, self.x, self.y)

    def __repr__(self):
        return "{}:({},{})".format(self.name, self.x, self.y)


def distance(node1: Node, node2: Node):
    '''
    计算两点间距离
    √[(x2-x1)^2+(y2-y1)^2]
    '''
    return ((node1.x - node2.x)**2 + (node1.y - node2.y)**2)**0.5


def edges():
    '''
    图的各边，假设各个顶点均相连，有 n*(n-1)/2 条
    Edges的结构：
        {
            A-V1: xxx,
            A-V2: xxx,
            A-V10: 11.66,
            ...
            V12-P78: xxx
        }
    '''
    Edges = {}
    Nodes = nodes()
    # 添加I型管道
    for node in Nodes:
        if node.type == 'V':
            Edges['A' + node.name] = distance(Nodes[0], node)
    # 添加II型管道
    for i in range(1, len(Nodes)):
        for j in range(i + 1, len(Nodes)):
            n1, n2 = Nodes[i].name, Nodes[j].name
            Edges[n1 + n2] = distance(Nodes[i], Nodes[j])
    return Edges


def nodes():
    '''
    返回全部节点
    '''
    Nodes = []
    with open("src/diagram/graph/pipe.csv", 'rt') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        for row in spamreader:
            Nodes.append(Node(row[1][0], row[1], row[2], row[3]))
    return Nodes


# 全局变量
Length = 0
Edges = edges()


def get_dis(node1, node2):
    '''
    查表返回两点间距离
    '''
    d = 0
    try:
        d = Edges[node1.name + node2.name]
    except KeyError:
        d = Edges[node2.name + node1.name]
    return d


def generate_tree():
    Nodes = nodes()
    graph, root = [], Nodes[0]

    # 中心供水站与一级供水站
    min_d = sys.maxsize
    nxt = None
    for node in Nodes:
        if node.type == 'V':
            d = Edges[root.name + node.name]
            if d < min_d:
                nxt, min_d = node, d
    # 删除已生成树的节点
    root.next.append(nxt)
    Nodes.remove(root)
    Nodes.remove(nxt)
    graph.append(nxt)

    # 一级供水站与二级供水站
    # curNode 是最小生成树中需要
    curNode = root.next
    while len(graph) < 180:
        nextNode, nextDis = None, sys.maxsize
        for cur in graph:
            for nxt in Nodes:
                d = get_dis(cur, nxt)
                if d < nextDis:
                    curNode, nextNode, nextDis = cur, nxt, d
        curNode.next.append(nextNode)
        graph.append(nextNode)
        Nodes.remove(nextNode)
    # print('graph size:', len(graph))
    return root


def dfs(root):
    global Length
    if root == None:
        return
    for node in root.next:
        # print(node.name, end=', ')
        Length += get_dis(root, node)
        dfs(node)
    # print()


def plot_nodes(Nodes):
    '''
    绘图
    不同颜色绘出181个点（和边，现在还没完成）
    '''
    fig = plt.figure(figsize=(10, 10))
    for i in range(len(Nodes)):
        color, x, y = Nodes[i].type, Nodes[i].x, Nodes[i].y
        if color == 'A':
            plt.scatter(x, y, s=30, c='black')
        elif color == 'V':
            plt.scatter(x, y, s=20, c='red')
            plt.text(x, y, Nodes[i].name, fontsize=7)
        else:
            assert color == 'P'
            plt.scatter(x, y, s=5, c='blue')
    plt.savefig("src/diagram/graph/nodes.png")


def plot_line(G, root):
    if root == None:
        print('None')
        return
    for node in root.next:
        G.add_edge(root.name, node.name,
                   weight=round(get_dis(root, node), 2))
        plot_line(G, node)


def plot_graph(root):
    G = nx.Graph()
    fig = plt.figure(figsize=(25, 25))
    plot_line(G, root)
    position = {nd.name: [nd.x, nd.y] for nd in nodes()}
    edge_labels = dict([((u, v,), d['weight'])
                        for u, v, d in G.edges(data=True)])
    # pos = nx.spring_layout(G, pos=position)
    nx.draw_networkx_edge_labels(G,
                                 width=3,
                                 font_size=8,
                                 pos=position,
                                 edge_labels=edge_labels,
                                 )
    
    nx.draw_networkx(G,
                     width=2,
                     font_size=10,
                     node_size=50,
                     pos=position,
                     node_color='#A0CBE2',
                     cmap=plt.cm.Dark2,
                     edge_cmap=plt.cm.Blues,
                     edge_color=[random.random() for i in range(len(G.edges))],
                    )
    plt.savefig('src/diagram/graph/graph.png')
    # plt.show()


if __name__ == "__main__":
    tree = generate_tree()
    dfs(tree)
    print("I:", Edges[tree.name+tree.next[0].name], "II:", Length)
    plot_graph(tree)
    plot_nodes(nodes())

